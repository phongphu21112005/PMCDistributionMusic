export const EMPTY_STRING = '';
export const ASTERISK = '*';
export const ZERO = '0';
export const DOUBLE_ZERO = '00';
export const EUR = 'EUR';