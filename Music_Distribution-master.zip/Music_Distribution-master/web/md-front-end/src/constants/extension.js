export const PNG = 'png';
export const MP3 = 'mp3';
export const APPLICATION_JSON = "application/json";
export const AUDIO_MPEG = "audio/mpeg";