export const DEFAULT_PAGE_NUMBER = 0;
export const DEFAULT_PAGE_SIZE = 7;
export const DEFAULT_SORT_ORDER = 'paymentInfo.tier,desc';
export const TOTAL_ELEMENTS = 'totalElements';