export const LOGGED_ARTIST = 'loggedArtist';
export const ACCESS_TOKEN = 'accessToken';
export const JWT_TOKEN = 'jwtToken';
export const ARTIST_ROLE = `ARTIST`;
