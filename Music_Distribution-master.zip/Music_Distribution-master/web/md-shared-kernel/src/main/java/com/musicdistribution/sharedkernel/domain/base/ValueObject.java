package com.musicdistribution.sharedkernel.domain.base;

/**
 * Abstract decorator for a value object.
 */
public interface ValueObject extends DomainObject {
}
