package com.musicdistribution.sharedkernel.domain.valueobjects.auxiliary;

/**
 * Enumeration for music genre.
 */
public enum Genre {
    Pop, Rock, Metal, Jazz, Funk, RnB
}
