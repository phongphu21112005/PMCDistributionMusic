package com.musicdistribution.sharedkernel.domain.valueobjects.auxiliary;

/**
 * Enumeration for money's currency.
 */
public enum Currency {
    EUR, USD, MKD
}
