package com.musicdistribution.sharedkernel.domain.valueobjects.auxiliary;

/**
 * Enumeration for email's domain.
 */
public enum EmailDomain {
    yahoo, gmail, outlook, students_finki
}
