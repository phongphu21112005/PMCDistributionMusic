package com.musicdistribution.streamingservice.constant

object NotificationConstants {

    const val CHANNEL_ID = "com.musicdistribution.streamingservice"
    const val CONTENT_TITLE = "Favourite Artist Publishing"
}