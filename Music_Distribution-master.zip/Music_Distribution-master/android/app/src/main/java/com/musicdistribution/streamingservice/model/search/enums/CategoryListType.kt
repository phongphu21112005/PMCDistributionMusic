package com.musicdistribution.streamingservice.model.search.enums

enum class CategoryListType {
    FAVOURITE_ITEMS,
    ALL_ITEMS
}