package com.musicdistribution.streamingservice.constant

object EmailConstants {

    const val COM = "${AlphabetConstants.DOT}com"
}