package com.musicdistribution.streamingservice.model.retrofit.partial

data class SongLength(
    val lengthInSeconds: Int,
    val formattedString: String,
)