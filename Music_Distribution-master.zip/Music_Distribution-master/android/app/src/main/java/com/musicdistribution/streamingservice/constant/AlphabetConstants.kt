package com.musicdistribution.streamingservice.constant

object AlphabetConstants {

    const val EMPTY_STRING = ""
    const val DOT = "."
    const val AT_SIGN = "@"
}