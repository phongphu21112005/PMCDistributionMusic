package com.musicdistribution.streamingservice.model.retrofit.partial.user

data class UserPersonalInfo(
    val firstName: String,
    val lastName: String,
    val artName: String,
    val fullName: String
)