package com.musicdistribution.streamingservice.model.enums

enum class Genre {
    Pop,
    Rock,
    Metal,
    Jazz,
    Funk,
    RnB
}