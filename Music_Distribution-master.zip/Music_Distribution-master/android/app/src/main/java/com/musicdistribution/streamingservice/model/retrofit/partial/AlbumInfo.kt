package com.musicdistribution.streamingservice.model.retrofit.partial

data class AlbumInfo(
    val artistName: String,
    val producerName: String,
    val composerName: String
)