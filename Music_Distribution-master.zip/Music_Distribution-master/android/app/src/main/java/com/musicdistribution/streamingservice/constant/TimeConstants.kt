package com.musicdistribution.streamingservice.constant

object TimeConstants {

    const val SPLASH_SCREEN_TIME: Long = 4000
}