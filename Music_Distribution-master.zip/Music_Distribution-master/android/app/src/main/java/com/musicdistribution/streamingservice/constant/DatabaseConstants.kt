package com.musicdistribution.streamingservice.constant

object DatabaseConstants {

    const val INSTANCE_NAME = "streamingservice.db"
}