package com.musicdistribution.streamingservice.model.enums

enum class EntityType {
    SONGS,
    ALBUMS,
    ARTISTS
}