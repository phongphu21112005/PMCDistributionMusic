package com.musicdistribution.streamingservice.model.enums

enum class EmailDomain {
    yahoo,
    gmail,
    outlook,
    students_finki
}