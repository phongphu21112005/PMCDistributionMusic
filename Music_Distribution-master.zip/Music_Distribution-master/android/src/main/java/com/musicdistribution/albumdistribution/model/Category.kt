package com.musicdistribution.streamingservice.model

data class Category(val title: String, val categoryItems: MutableList<CategoryItem>)