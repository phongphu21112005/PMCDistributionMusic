package com.musicdistribution.streamingservice.domain

data class Song(val id: String, val name: String, val isASingle: Boolean, val length: Long)