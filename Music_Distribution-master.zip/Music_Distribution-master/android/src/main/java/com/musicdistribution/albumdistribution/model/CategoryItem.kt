package com.musicdistribution.streamingservice.model

class CategoryItem(val itemId: Int, val imageUrL: Int)