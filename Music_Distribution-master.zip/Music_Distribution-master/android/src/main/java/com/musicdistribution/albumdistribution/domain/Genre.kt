package com.musicdistribution.streamingservice.domain

enum class Genre {
    Rock,
    Indie,
    Metal,
    Jazz,
    Blues,
    Soul,
    Funk,
    Pop,
    Industrial
}