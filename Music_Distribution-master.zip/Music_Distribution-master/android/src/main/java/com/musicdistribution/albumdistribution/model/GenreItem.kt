package com.musicdistribution.streamingservice.model

data class GenreItem (val genreName: String, val genreImage: Int)