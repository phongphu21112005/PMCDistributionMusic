package com.musicdistribution.streamingservice.domain

enum class Role {
    LISTENER,
    CREATOR,
    ADMINISTRATOR
}