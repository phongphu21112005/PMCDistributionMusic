package com.musicdistribution.streamingservice.model

class SearchItem (val searchItemTitle: String, val searchItemType: String, val searchItemImage: Int)